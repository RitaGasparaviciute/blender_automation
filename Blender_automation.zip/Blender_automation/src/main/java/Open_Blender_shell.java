
import java.io.IOException;

public class Open_Blender_shell {

    public  void runCmd() {

        Process sh;

        try {
            sh = Runtime.getRuntime ().exec (new String[]{"bash", "home/$=USER/autostart.sh"});
        } catch (IOException e)
        {
            e.printStackTrace ();
        }
    }
}
