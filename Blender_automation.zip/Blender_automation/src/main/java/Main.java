public class Main {

    public static void main(String[] args) {
        Open_Blender_shell cmd = new Open_Blender_shell ();
        cmd.runCmd ();
        System.out.println ("ok");
    }
}
