package com.company;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;

    public abstract class OpenBender {

        public static void main(String[] args) throws IOException {
            //Gali reikt pakoreguot path
            File file = new File("/home/user/source.txt");

            //Ar Java Desktop gali veikt ant sito pc
            if(!Desktop.isDesktopSupported()){
                System.out.println("Script won't work, on this platform sorry");
                return;
            }

            Desktop desktop = Desktop.getDesktop();
            if(file.exists()) desktop.open(file);

            //Atidaro Blender (tikiuosi)
            file = new File("/home/user/Blender.desktop");
            if(file.exists()) desktop.open(file);
        }

    }

}
