package com.company;

import java.util.Scanner;

class GetInputFromUser {
    public static void main(String args[]) {
        try (Scanner in = new Scanner(System.in)) {
            System.out.println("Enter Your Username to open Blender");
            String user = in.nextLine();
        }
    }
}